### Section 5 - Handling server data
- TBD
