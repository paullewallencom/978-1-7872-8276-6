### Section 1 - Up and running with Redux
- TBD
