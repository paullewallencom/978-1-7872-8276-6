### Section 4 - Working with deeply nested data
- TBD
