### Section 3 - Middlewares in Redux
- TBD
